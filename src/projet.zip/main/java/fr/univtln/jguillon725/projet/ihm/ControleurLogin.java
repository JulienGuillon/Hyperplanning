package fr.univtln.jguillon725.projet.ihm;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.ModelEdt;
import fr.univtln.jguillon725.projet.model.ModelLogin;
import fr.univtln.jguillon725.projet.model.entities.Person;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

/**
 * Created by julien on 13/10/15.
 */
public class ControleurLogin {
    private IView vueLogin;
    private ModelLogin modeleLogin;

    private Document loginModel = new PlainDocument();
    private Document passwordModel = new PlainDocument();

    public ControleurLogin(final VueLogin vueLogin, ModelLogin modeleLogin) {
        this.vueLogin = vueLogin;
        this.modeleLogin = modeleLogin;

        DocumentListener ecouteurChangementTexte = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                changedUpdate(e);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                changedUpdate(e);

            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                if ((loginModel.getLength() == 0 || passwordModel.getLength() == 0))
                    vueLogin.setConnexionOk(false);
                else
                    vueLogin.setConnexionOk(true);
            }
        };

        loginModel.addDocumentListener(ecouteurChangementTexte);
        passwordModel.addDocumentListener(ecouteurChangementTexte);
    }
    public Document getLoginModel()
    {
        return loginModel;
    }

    public Document getPasswordModel()
    {
        return passwordModel;
    }

    public void seConnecter() {
        try {
            //L'ajout d'un auteur est délégué au modèle.
            Person person = modeleLogin.verifierIdentifiant(
                    loginModel.getText(0, loginModel.getLength()),
                    passwordModel.getText(0, passwordModel.getLength())
            );
            this.vueLogin.setVisible(false);
            ModelEdt modelEdt = new ModelEdt(person);
            vueLogin = new ViewEdt(modelEdt);
            this.vueLogin.setVisible(true);

        } catch (BadLocationException e) {
            e.printStackTrace();
        } catch (PersistanceException e) {
            e.getException().printStackTrace();
        }
        clearIdentifiant();
    }

    public void clearIdentifiant() {
        try {
            loginModel.remove(0, loginModel.getLength());
            passwordModel.remove(0, passwordModel.getLength());
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }
}
