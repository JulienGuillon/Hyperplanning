package fr.univtln.jguillon725.projet.ihm;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.ModelEdt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by julien on 15/10/15.
 */
public class ViewEdt extends JFrame implements IView<ModelEdt> {
    private final ModelEdt modelEdt;
    private final ControlerEdt controleurEdt;

    private final JPanel panelInformation = new JPanel(new GridBagLayout());
    private final JPanel panelEdt = new JPanel(new GridBagLayout());
    private final JPanel panelPlanning = new JPanel(new GridBagLayout());

    private final JPanel panelDay = new JPanel(new GridBagLayout());
    private final JPanel panelHour = new JPanel(new GridBagLayout());

    private final String[] listDay= {"Heure", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};
    private final JLabel[] labelDay = new JLabel[listDay.length];
    private final JLabel[] labelHour = new JLabel[11];

    private final JLabel connectionJLabel = new JLabel("Vous etes connecté");

    public void createView(ModelEdt modelEdt) throws PersistanceException {
        new ViewEdt(modelEdt);
    }

    public ViewEdt(ModelEdt modelEdt) throws PersistanceException {
        super("EDT");
        setSize(800, 600);
        this.modelEdt = modelEdt;
        this.controleurEdt = new ControlerEdt(this, modelEdt);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;

        int i = 0;
        for(String s: listDay)
        {
            labelDay[i] = new JLabel(listDay[i]);
            c.gridx = i;
            c.gridy = 0;
            c.insets = new Insets(10,10,10,10);
            panelDay.add(labelDay[i], c);
            i++;
        }

        for(int j=8; j<19; j++)
        {
            labelHour[j-8] = new JLabel(Integer.toString(j));
            c.gridx = 0;
            c.gridy = j-8;
            panelHour.add(labelHour[j-8], c);
        }

        this.connectionJLabel.setText(connectionJLabel.getText()+" sous le nom "+modelEdt.getPerson().getNom());
        c.gridx = 0;
        c.gridy = 0;
        panelInformation.add(this.connectionJLabel, c);

        c.gridwidth = 7;
        panelEdt.setPreferredSize(new Dimension(100,100));
        panelEdt.setBackground(Color.ORANGE);
        panelEdt.add(panelDay, c);

        c.fill = GridBagConstraints.VERTICAL;
        c.gridy = 1;
        c.gridwidth = 10;

        c.anchor = GridBagConstraints.WEST;
        panelEdt.add(panelHour, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 7;
        c.gridheight = 1;
        JPanel panelLunch = new JPanel();
        panelLunch.setBackground(Color.red);
        panelPlanning.add(panelLunch, c);

        c.fill = GridBagConstraints.BOTH;
        c.gridy = 1;
        c.gridx = 1;
        panelEdt.add(panelPlanning, c);

        c.fill = GridBagConstraints.HORIZONTAL;

        controleurEdt.getPlanningWeek(panelPlanning);

        getContentPane().add(panelInformation,BorderLayout.NORTH);
        c.gridx = 0;
        c.gridy = 1;
        getContentPane().add(panelEdt, BorderLayout.CENTER);

        setVisible(true);
    }


}
