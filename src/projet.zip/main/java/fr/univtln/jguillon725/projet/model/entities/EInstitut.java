package fr.univtln.jguillon725.projet.model.entities;

/**
 * Created by julien on 16/10/15.
 */
public class EInstitut {
}
