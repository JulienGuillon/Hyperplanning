package fr.univtln.jguillon725.projet.model;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.entities.Person;

import java.util.Observable;
import java.util.Observer;
import java.util.logging.Logger;

/**
 * Created by julien on 13/10/15.
 */
public class ModelLogin extends Observable implements Observer {
    private static final ModelLogin MODEL_LOGIN = new ModelLogin();
    private static Logger logger = Logger.getLogger(ModelLogin.class.getName());

    private ModelLogin(){}

    public static ModelLogin getInstance()
    {
        return MODEL_LOGIN;
    }


    @Override
    public void update(Observable o, Object arg) {
        logger.info("Model changed : " + arg);
        setChanged();
        notifyObservers();
    }

    public Person verifierIdentifiant(String login, String password) throws PersistanceException
    {
        return CEntityManagerPerson.find(login, password);
    }


}
