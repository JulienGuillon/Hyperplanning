package fr.univtln.jguillon725.projet.ihm;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.ModelEdt;

import javax.swing.*;

/**
 * Created by julien on 15/10/15.
 */
public class ControlerEdt {
    private ViewEdt viewEdt;
    private ModelEdt modelEdt;

    public ControlerEdt(ViewEdt viewEdt, ModelEdt modelEdt) {
        this.viewEdt = viewEdt;
        this.modelEdt = modelEdt;
    }

    public void getPlanningWeek(JPanel pPanel) throws PersistanceException {
        this.modelEdt.getPlanningWeek(pPanel);
    }


}
