package fr.univtln.jguillon725.projet.model;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.entities.CCourse;
import fr.univtln.jguillon725.projet.model.entities.Person;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by julien on 15/10/15.
 */
public class ModelEdt extends Observable implements Observer{
    private Person person;
    private int week;
    private int year;
    private int month;
    private int firtsDayOfWeek;

    public ModelEdt(Person person)
    {
        this.person = person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Person getPerson() {
        return person;
    }

    @Override
    public void update(Observable o, Object arg) {
        setChanged();
        notifyObservers();
    }

    public void getPlanningWeek(JPanel pPanel) throws PersistanceException {
        Calendar cal = Calendar.getInstance();
        List<List<CCourse>> listCourseByWeek = new ArrayList<List<CCourse>>();

        this.week = cal.get(Calendar.WEEK_OF_YEAR);
        this.year = cal.get(Calendar.YEAR);
        this.month = cal.get(Calendar.MONTH);
        cal.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);
        this.firtsDayOfWeek = cal.get(Calendar.DAY_OF_MONTH);

        for(int numDay=firtsDayOfWeek; numDay<firtsDayOfWeek+6; numDay++)
        {
            List<CCourse> listCourseByDay;
            listCourseByDay = CEntityManagerCourse.findByDay(numDay);
            listCourseByWeek.add(listCourseByDay);

            int i = 0;
            for(CCourse course: listCourseByDay) {
                GridBagConstraints c = new GridBagConstraints();
                c.fill = GridBagConstraints.VERTICAL;
                c.weighty = 1;
                c.gridx = i;
                c.gridy = course.getHour() - 8;
                c.gridheight = course.getDuree();
                System.out.println(course.getHour());
                JPanel panelCourse = new JPanel();
                panelCourse.add(new JLabel(course.getSubject()), BorderLayout.CENTER);
                pPanel.add(panelCourse, c);
                i++;
            }
        }



    }
}
