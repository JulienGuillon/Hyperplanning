package fr.univtln.jguillon725.projet.ihm;

import fr.univtln.jguillon725.projet.exceptions.PersistanceException;
import fr.univtln.jguillon725.projet.model.ModelLogin;

/**
 * Created by julien on 15/10/15.
 */
public class ViewAffichage<T> implements IView<T> {
    private IView view;

    public ViewAffichage() throws PersistanceException {
        this.view = new VueLogin();
        this.view.createView(ModelLogin.getInstance());
    }

    public ViewAffichage(IView view, T model) throws PersistanceException {
        this.view = view;
        this.view.createView(model);

    }
    @Override
    public void createView(Object iModel){}

    @Override
    public void setVisible(boolean b) {

    }
}
